from django.shortcuts import render, get_object_or_404
from rest_framework.generics import ListAPIView, CreateAPIView, RetrieveAPIView, DestroyAPIView, UpdateAPIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from .models import *
from .serializers import *
from rest_framework.pagination import PageNumberPagination
from rest_framework import status

# Create your views here.
class BlogListView(ListAPIView):

    queryset = Blog.objects.all()
    pagination = PageNumberPagination
    serializer_class = BlogSerializer

class BlogRetrieveView(RetrieveAPIView):

    serializer_class = BlogSerializer
    queryset = Blog.objects.all()

class BlogCreateView(CreateAPIView):
    
    permission_classes = [IsAuthenticated]
    serializer_class = BlogSerializer
    queryset = Blog.objects.all()

class BlogEditView(UpdateAPIView):
    
    permission_classes = [IsAuthenticated]
    serializer_class = BlogSerializer
    queryset = Blog.objects.all()

class BlogDeleteView(DestroyAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = BlogSerializer
    queryset = Blog.objects.all()

class BlogCommentView(CreateAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = CommentSerializer
    queryset = Comment.objects.all()
    