from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Blog(models.Model):

    title = models.CharField(max_length=100)
    content = models.TextField(null=True, blank=True)
    publication_date = models.DateTimeField(auto_now_add=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    categories = models.ManyToManyField("Categories", blank=True)

    def __str__(self) -> str:
        return self.title


class Comment(models.Model):

    blog = models.ForeignKey(Blog, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.TextField()
    updated = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"{self.user.get_username()}: {self.blog}: {self.comment[:50]}"

class Tags(models.Model):

    blog = models.ForeignKey(Blog, on_delete=models.CASCADE)
    tag = models.CharField(max_length=50)

    def __str__(self) -> str:
        return f"{self.blog} - {self.tag}"

class Categories(models.Model):

    category = models.CharField(max_length=100, unique=True)

    def __str__(self) -> str:
        return self.category
